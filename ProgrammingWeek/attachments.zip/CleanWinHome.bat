@echo off
echo Cleaning up temporary files
del /q /s "%TEMP%\*"

echo Cleaning up user-specific temporary files
del /q /s "%USERPROFILE%\AppData\Local\Temp\*"

echo Cleaning up Recycle Bin
rd /s /q C:\$Recycle.Bin

echo Cleaning up temporary internet files
rd /s /q "%LocalAppData%\Microsoft\Windows\INetCache"

echo Cleaning up Windows Update cache
rd /s /q C:\Windows\SoftwareDistribution\Download

echo Cleaning up old prefetch files
del /q /s C:\Windows\Prefetch\*

echo Cleaning up Download
del /q /s "%USERPROFILE%\Downloads\*"

echo Cleaning up Download
del /q /s "%USERPROFILE%\Document\*"

echo Cleanup complete!
pause